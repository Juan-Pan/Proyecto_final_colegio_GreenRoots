<?php
	session_start();
	if (isset($_REQUEST['cerrar_sesion']))
	{
		session_unset();
		session_destroy();
	}

	if (isset($_SESSION['perfil']))
	{
		switch($_SESSION['perfil'])
		{
			case 1:
				header('location:administrador.php');
			break;
			
			case 2:
				header('location:colaborador.php');
			break;		
			
			default:
		}
	}

	if (isset($_REQUEST['inputUsuario']) && isset($_REQUEST['inputPassword']))
	{
		$username = $_REQUEST['inputUsuario'];
		$password = $_REQUEST['inputPassword'];
		$password = md5($password);
		
		// Consultando información del Administrador
		require ("funciones1.php");	// Funciones escritas en PHP
		$idCone = conexion();		
		
		
		
		$SQL = "SELECT id_perfil, nombre FROM autenticar_usuario WHERE username = '$username' AND password = '$password'";
		
		$registro = mysqli_query($idCone,$SQL);																		
		while($tupla = mysqli_fetch_row($registro))																		
		{													
			$id_perfil = $tupla[0];
			$nombre = $tupla[1];						
		}
		$registros = mysqli_num_rows($registro);
		mysqli_free_result ($registro);
		mysqli_close($idCone);
		// Consultando información del Administrador
		
		if ($registros > 0)
		{
			$_SESSION['perfil'] = $id_perfil;
			$_SESSION['nombre'] = $nombre;
			
			switch($_SESSION['perfil'])
			{
				case 1:					
					header("location:administrador.php");
				break;
				
				case 2:
					header("location:colaborador.php");
				break;		
				
				default:
			}
		}
		else
		{			
			?>
			<div class="alert alert-danger" align="center" role="alert">
				Datos incorrectos!							
			</div>	
			<?php
		}
	}	
?>
<!doctype html>
<html lang="es">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="shortcut icon" href="GreenRoots.png">
    <!-- fin Bootstrap CSS -->
    <!-- fuente -->
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap');
    </style>
    <style>
      * {
box-sizing: border-box;
}

*:focus {
	outline: none;
}
body {
font-family: Arial;
background-color: #3498DB;
padding: 50px;
}
.login {
margin: 20px auto;
width: 300px;
}
.login-screen {
background-color: #FFF;
padding: 20px;
border-radius: 5px
}

.app-title {
text-align: center;
color: #777;
}

.login-form {
text-align: center;
}
.control-group {
margin-bottom: 10px;
}

input {
text-align: center;
background-color: #ECF0F1;
border: 2px solid transparent;
border-radius: 3px;
font-size: 16px;
font-weight: 200;
padding: 10px 0;
width: 250px;
transition: border .5s;
}

input:focus {
border: 2px solid #3498DB;
box-shadow: none;
}

.btn {
  border: 2px solid transparent;
  background: #3498DB;
  color: #ffffff;
  font-size: 16px;
  line-height: 25px;
  padding: 10px 0;
  text-decoration: none;
  text-shadow: none;
  border-radius: 3px;
  box-shadow: none;
  transition: 0.25s;
  display: block;
  width: 250px;
  margin: 0 auto;
}

.btn:hover {
  background-color: #2980B9;
}

.login-link {
  font-size: 12px;
  color: #444;
  display: block;
	margin-top: 12px;
}

    </style>
    <!-- fin fuente -->
    <title>Iniciar Sesión </title>
  </head>
  <body style= "background-color: #272121">
    <!-- Just an image -->
    <body>
      
	<div class="login">
		<div class="login-screen">
			<div class="app-title">
				<h1>Entrar</h1>
			</div>

			<div class="login-form">
				<div class="control-group">
				<input type="text" class="login-field" value="" placeholder="usuario" id="login-name">
				<label class="login-field-icon fui-user" for="login-name"></label>
				</div>

				<div class="control-group">
				<input type="password" class="login-field" value="" placeholder="contraseña" id="login-pass">
				<label class="login-field-icon fui-lock" for="login-pass"></label>
				</div>

				<a class="btn btn-primary btn-large btn-block" href="index.php">Iniciar</a>
				
			</div>
		</div>
	</div>
</body>
    

   


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
    -->
  </body>
</html>